﻿using System;

namespace ReturningValueSecond
{
    class Program
    {
       public static String fullName()
        {
            String firstName = "Sabin";
            String lastName = "Mahato";
            string fullName = firstName + " " + lastName;
            return fullName;
        }
        static void Main(string[] args)
        {
            String name = fullName();
            Console.WriteLine(name);
            Console.ReadLine();
        }
    }
}
