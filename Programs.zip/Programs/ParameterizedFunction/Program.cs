﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterizedFunction
{
    class Program
    {
        public static int sumCalculator(int[] x)
        {
            int sum = 0;
            for (int i = 0; i < x.Length; i++)
            {
                sum += x[i];
            }
            return sum;
        }
        static void Main(string[] args)
        {
            int[] first = { 100,200,300,500,600,800,900};
            int[] second = { 3, 4, 5, 6, 99, 76, 87, 97 };
            int[] third = { 1200, 1234, 7890, 7654, 6789, 4321 };
            Console.WriteLine("Sum of elements of first array: {0}",sumCalculator(first));
           
            Console.WriteLine("Sum of elements of second array:{0}",sumCalculator(second));
            
            Console.WriteLine("Sum of elements of third array{0}",sumCalculator(third));
           
            Console.ReadLine();
        }
    }
}
