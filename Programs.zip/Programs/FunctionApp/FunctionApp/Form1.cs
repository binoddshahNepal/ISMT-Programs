﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FunctionApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Double totalBill = 0, amount = 0;
        int serial = 0;
        private void btnAddTolist_Click(object sender, EventArgs e)
        {
            serial++;
            String name = txtProductName.Text;
            Double rate = Double.Parse(txtRate.Text);
            Double qty = Double.Parse(txtQuantity.Text);
            amount = rate * qty;
            dgvDetails.Rows.Add(serial, name, rate, qty, amount);
            totalBill += amount;
            lblTotalBillingAmount.Text = totalBill.ToString();
           

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            blank();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            blank();
            dgvDetails.Rows.Clear();
            lblTotalBillingAmount.Text = "0";
        }

        public void blank()
        {
            txtProductName.Clear();
            txtQuantity.Clear();
            txtRate.Clear();
        }
    }
}
