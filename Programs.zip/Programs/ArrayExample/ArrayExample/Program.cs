﻿using System;

namespace ArrayExample
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] names = { "Ram", 
                "Shyam", 
                "Hari", 
                "Gopal", 
                "Harish", 
                "Manish", 
                "Suresh" };
            for(int i=0;i<names.Length;i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Retrieving values by using for each loop");
            foreach(String s in names)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Retrieving values by using for each loop and var ");
            foreach (var s in names)
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
        }
    }
}
