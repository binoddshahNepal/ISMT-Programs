﻿using System;
using System.Collections.Generic;
namespace ListExample2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> pname = new List<String>();
            List<Double> rate = new List<Double>();
            List<Double> quantity = new List<Double>();
            Double amount = 0, totalBill = 0;
            int n;
            Console.Write("\nEnter the total number of products:\t");
            n = int.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("DETAILS OF THE ITEMS PURCHASED");
            Console.WriteLine("..........................................");
            for(int i=0;i<n;i++)
            {
                Console.Write("\nProduct Name:      \t");
                pname.Add(Console.ReadLine());
                Console.Write("\nRate:              \t");
                rate.Add(Double.Parse(Console.ReadLine()));
                Console.Write("\nQuantity:          \t");
                quantity.Add(Double.Parse(Console.ReadLine()));
                Console.Clear();
            }
            Console.WriteLine("----------DETAILS OF THE ITEMS PURCHASED----------");
            Console.WriteLine("--------------------------------------------------\n");
            for(int i=0;i<pname.Count;i++)
            {
                Console.WriteLine("{0}\t\t{1}\t{2}", pname[i], rate[i], quantity[i]);
                amount = rate[i] * quantity[i];
                totalBill += amount;
            }
            Console.WriteLine("--------------------------------------------------\n");
            Console.WriteLine("TOTAL BILLING AMOUNT:    {0}", totalBill);
            Console.WriteLine("--------------------------------------------------\n");
            Console.ReadLine();
        }
    }
}
