﻿using System;

namespace GS
{
    class Program
    {
        static void Main(string[] args)
        {
            Double a, r, n;
            Console.Write("\nEnter the first term:\t");
            a = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter the common ratio:\t");
            r = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter the total number of terms:\t");
            n = Double.Parse(Console.ReadLine());
            Console.Clear();
            for(int i=0;i<n;i++)
            {
                Double tn = a * r * Math.Pow(r, i - 1);
                Console.Write("{0}\t", tn);
            }
            Console.ReadLine();
        }
    }
}
