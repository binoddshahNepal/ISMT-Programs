﻿using System;

namespace whileLoop_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            do
            {
                Console.WriteLine(x);
            } while (x == 2) ;
                Console.ReadLine();
        }
    }
}
