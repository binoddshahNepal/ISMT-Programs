﻿using System;

namespace Variable
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] names = new string[10];
            names[0] = "Ram";
            names[1] = "Shyam";
            names[2] = "Hari";
            names[3] = "Suresh";
            names[4] = "Manish";
            names[5] = "Shekhar";
            Console.WriteLine(names[0]);
            Console.WriteLine(names[1]);
            Console.WriteLine(names[2]);
            Console.WriteLine(names[3]);
            Console.WriteLine(names[4]);
            Console.WriteLine(names[5]);

            Console.ReadLine();
            Console.Clear();
            for(int i=0;i<5;i++)
            {
                Console.Write("\nEnter the name:\t");
                names[i] = Console.ReadLine();
            }
            Console.Clear();
            for(int i=0;i<5;i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.ReadLine();
            Console.Clear();
            for(int i=0;i<names.Length;i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.ReadLine();
        }
    }
}
