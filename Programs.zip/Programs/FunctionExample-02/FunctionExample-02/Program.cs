﻿using System;

namespace FunctionExample_02
{
    class Program
    {
        public static void getMeans(Double[] numbers)
        {
            Double sum = 0;
            
            for(int i=0;i<numbers.Length;i++)
            {
                sum += numbers[i];
                Console.WriteLine(numbers[i]);
            }
            Double mean = sum / numbers.Length;
            Console.WriteLine("The mean of the array elements: {0}", mean);
        }
        static void Main(string[] args)
        {
            Double[] x = { 100, 200, 400, 800, 999, 87, 899, 889, 6654, 9999 };
            Double[] y = { 77, 88, 99, 99, 76, 89, 98, 99, 764, 679 };
            Double[] z = { 89.99, 78.99, 76.98, 90.99,88.76};
            Console.WriteLine("Mean for the first array element");
            getMeans(x);
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Mean for the second array element");
            getMeans(y);
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("Mean for the third array element");
            getMeans(z);
            Double[] a = new double[10];
            for(int i=0;i<a.Length;i++)
            {
                Console.Write("{0}: ", i);
                a[i] = Double.Parse(Console.ReadLine());
            }
            Console.WriteLine("Mean for the Fourth( User Defined) array element");
            getMeans(a);
            Console.ReadLine();
        }
    }
}
