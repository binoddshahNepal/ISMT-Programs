﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUIReturningValue
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Double first, second;
        bool blankvalue()
        {
            if(txtFirstNumber.Text=="" || txtSecondNumber.Text=="")
            {
                return false;
            }
            else { return true; }
        }
        void readValues()
        {
            if(blankvalue()==false)
            {
                MessageBox.Show("Fields cannot be blank");
            }
            else
            {
                first = Double.Parse(txtFirstNumber.Text);
                second = Double.Parse(txtSecondNumber.Text);
            }
        }
        Double addition()
        {
            readValues();
            return (first + second);
        }
        Double subtraction()
        {
            readValues();
            return (first - second);
        }
        Double multiplication()
        {
            readValues();
            return (first * second);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lblResult.Text = addition().ToString();
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            lblResult.Text = subtraction().ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            lblResult.Text = multiplication().ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            lblResult.Text = division().ToString();
        }

        Double division()
        {
            readValues();
            return (first / second);
        }
    }
}
