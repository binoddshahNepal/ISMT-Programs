﻿using System;
using System.Data;

namespace ClassExample
{
    class Employee
    {
        int age;
        String name, designation;
        Double salary;
        //Member Methods/Function can access member properties/variables regardless of access modifier.
        public void getValues()
        {
            Console.Write("\nEnter employee name:\t");
            name = Console.ReadLine();
            Console.Write("\nEnter the designation:\t");
            designation = Console.ReadLine();
            Console.Write("\nEnter the age:\t");
            age = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the salary:\t");
            salary = Double.Parse(Console.ReadLine());
        }
        public void printValues()
        {
            Console.WriteLine("Employee Name :   {0}", name);
            Console.WriteLine("Designation   :   {0}", designation);
            Console.WriteLine("Age           :   {0}", age);
            Console.WriteLine("Salary        :   {0}", salary);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.getValues();
            Console.Clear();
            emp.printValues();
            Console.ReadLine();

        }
    }
}
