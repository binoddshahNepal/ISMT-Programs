﻿using System;

namespace Function_14Sept2020
{
    class Program
    {
       
        public static int addition()
        {
            
            int x = 100, y = 500;
            return (x + y);
        }
        static void Main(string[] args)
        {
           int x= addition();
            Console.WriteLine(x);
            Console.ReadLine();
        }
    }
}
