﻿using System;

namespace MenuDriven
{
    class Program
    {
        static int x, y;
        public static  void getValues()
        {
            Console.Write("\nEnter first number:\t");
            x = int.Parse(Console.ReadLine());
            Console.Write("\nEnter second number:\t");
            y = int.Parse(Console.ReadLine());
        }
        public static  int addition()
        {
            return (x + y);
        }
        public static int substraction()
        {
            return (x - y);
        }
        public static int multiplication()
        {
            return (x * y);
        }
        public static int division()
        {
            return (x / y);
        }
        static void Main(string[] args)
        {
            int a = 1;
            while(a==1)
            {
                Console.WriteLine("Press 1 for addition");
                Console.WriteLine("Press 2 for subtraction");
                Console.WriteLine("Press 3 for multiplication");
                Console.WriteLine("Press 4 for division");
                Console.WriteLine("Press any other value to exit");
                Console.Write("\nEnter your choice:\t");
                int choice = int.Parse(Console.ReadLine());
                switch(choice)
                {
                    case 1:
                        getValues();
                        int sum = addition();
                        Console.WriteLine("The sum of the numbers: {0}",sum);
                        break;
                    case 2:
                        getValues();
                        int difference = substraction();
                        Console.WriteLine("The difference of the numbers : {0}", difference);
                        break;
                    case 3:
                        getValues();
                        int product = multiplication();
                        Console.WriteLine("The product of the numbers : {0}", product);
                        break;
                    case 4:
                        getValues();
                        int quotient = division();
                        Console.WriteLine("The quotient of the numbers : {0}", quotient);
                        break;
                    default:
                        a = 0;
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}
