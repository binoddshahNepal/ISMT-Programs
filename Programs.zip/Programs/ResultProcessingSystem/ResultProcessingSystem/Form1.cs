﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResultProcessingSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        String subjectName;
        Double fullMark;
        Double passMark;
        Double obtainedMark;
        int serial = 0;
        String remarks;
        Double totalFull, totalObtained;
        bool status = true;
        private void btnAddToList_Click(object sender, EventArgs e)
        {
            
            serial++;
            subjectName = txtSubjectName.Text;
            fullMark = Double.Parse(txtFullMark.Text);
            passMark = Double.Parse(txtPassMark.Text);
            obtainedMark = Double.Parse(txtObtainedMark.Text);
            if(obtainedMark<passMark)
            {  remarks = "Fail";status = false; }
            else { remarks = "Pass";}
            if (fullMark < 0 || passMark < 0)
            {
                MessageBox.Show("Marks cannot be negative");
                txtFullMark.Clear();
                txtPassMark.Clear();
                txtFullMark.Focus();
            }
            else if(passMark>fullMark)
            {
                MessageBox.Show("Pass mark cannot be greater than full mark");
                txtPassMark.Clear();
                txtFullMark.Focus();

            }
            else if(obtainedMark>fullMark)
            {
                MessageBox.Show("Obtained Mark cannot be greater than full mark");
                txtObtainedMark.Clear();
                txtObtainedMark.Focus();
               
            }
            else
            {
                dgvResult.Rows.Add(serial, subjectName, fullMark, passMark, obtainedMark, remarks);
                totalFull += fullMark;
                totalObtained += obtainedMark;
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtStudentId.Clear();
            txtSubjectName.Clear();
            txtFullMark.Clear();
            txtPassMark.Clear();
            txtObtainedMark.Clear();
            dgvResult.Rows.Clear();
            lblPercentage.Text = "0";
            lblGrade.Text = "N/A";
            fullMark = 0;
            passMark = 0;
            obtainedMark = 0;
            totalFull = 0;
            totalObtained = 0;
            serial = 0;
        }

        private void btnGrading_Click(object sender, EventArgs e)
        {
            for(int i=0;i<dgvResult.Rows.Count;i++)
            {
                string r = dgvResult.Rows[i].Cells[5].Value.ToString();
                if(r=="Fail")
                {
                    dgvResult.Rows[i].DefaultCellStyle.BackColor = Color.Red;
                }
                else
                {
                    dgvResult.Rows[i].DefaultCellStyle.BackColor = Color.Green;
                }
            }
            Double percentage = totalObtained / totalFull * 100;
            lblPercentage.Text = percentage.ToString();
          if(status==true)
            {
                if(percentage>=80)
                {
                    lblGrade.Text = "Distinction";
                }
                else if(percentage<80 && percentage>=60)
                {
                    lblGrade.Text = "First Division";
                }
                else if(percentage<60 && percentage>=50)
                {
                    lblGrade.Text = "Second Division";
                }
                else if(percentage<50 && percentage>=32)
                {
                    lblGrade.Text = "Third Division";
                }
                else { lblGrade.Text = "N/A"; }
            }
          else
            {
                lblGrade.Text = "N/A";
            }
        }
    }
}
