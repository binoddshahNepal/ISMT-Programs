﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism_01
{
    class Arithmetic
    {
        public void add()
        {
            Console.Write("\nEnter first number:\t");
            int first = int.Parse(Console.ReadLine());
            Console.Write("\nEnter second number:\t");
            int second = int.Parse(Console.ReadLine());
            int sum = first + second;
            Console.WriteLine("the sum of the numbers : {0}", sum);
        }
        public void add(int x, int y)
        { 
            Console.WriteLine("The sum of the numbers : {0}", x + y); 
        }
        public void add(int x, int y, int z)
        { 
            Console.WriteLine("The sum of the numbers : {0}", x + y + z); 
        }
    }
}
