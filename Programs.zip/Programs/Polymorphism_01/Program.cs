﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Arithmetic a = new Arithmetic();
            Console.WriteLine("From First Function");
            a.add();
            Console.WriteLine("\nFrom Second Function");
            a.add(100, 200);
            Console.WriteLine("\nFrom Third Function");
            a.add(300, 400, 500);
            Console.ReadLine();
        }
    }
}
