﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionParameterized
{
    class Program
    {
        static void add(int x, int y)
        {
            int sum = (x + y);
            Console.WriteLine("The sum of the number is : {0}",sum);
        }
        static void fullName(String firstName, String lastName)
        {
            String fn = firstName + " " + lastName;
            Console.WriteLine("Welcome: {0}", fn);
        }
        static void Main(string[] args)
        {
            add(500, 800);
            fullName("Ram", "Shrestha");
            Console.ReadLine();
        }
    }
}
