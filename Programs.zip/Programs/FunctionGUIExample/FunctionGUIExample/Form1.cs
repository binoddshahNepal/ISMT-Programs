﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FunctionGUIExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public Double length, breadth, height;
       
        public void getValues()
        {
            
           if(txtLength.Text=="")
            {
                MessageBox.Show("Length Fields cannot be blank");
            }
           else if(txtBreadth.Text=="")
            {
                MessageBox.Show("Breadth Field cannot be blank");
            }
           else if(txtHeight.Text=="")
            {
                MessageBox.Show("Height fields cannot be blank");
            }
           else
            {
                length = Double.Parse(txtLength.Text);
                breadth = Double.Parse(txtBreadth.Text);
                height = Double.Parse(txtHeight.Text);
            }
              
          
            
        }
        public void clear()
        {
            txtBreadth.Clear();
            txtLength.Clear();
            txtHeight.Clear();
        }
        private void btnAreaofFloor_Click(object sender, EventArgs e)
        {
            getValues();
         
           
               
                Double area = length * breadth;
                lblMessage.Text = "Area of Floor";
                lblResult.Text = area.ToString();
                clear();
           
            
        }

        private void btnAreaofFourWalls_Click(object sender, EventArgs e)
        {
            getValues();
            Double fourWalls = 2 * height * (length + breadth);
            lblMessage.Text = "Area of Four Walls";
            lblResult.Text = fourWalls.ToString();
            clear();
        }

        private void btnVolumeOfRoom_Click(object sender, EventArgs e)
        {
            getValues();
            Double volume = length * breadth * height;
            lblMessage.Text = "Volume of the Room";
            lblResult.Text = volume.ToString();
            clear();
        }
    }
}
