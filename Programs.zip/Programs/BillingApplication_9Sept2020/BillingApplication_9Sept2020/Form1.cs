﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillingApplication_9Sept2020
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int serial = 0;
        Double discount = 0;
        Double grossTotal = 0;
        private void btnAddToList_Click(object sender, EventArgs e)
        {
            serial++;
            String productName = txtProductName.Text;
            Double rate = Double.Parse(txtRate.Text);
            Double quantity = Double.Parse(txtQuantity.Text);
            Double Amount = rate * quantity;
            dgvDetails.Rows.Add(serial, productName, rate, quantity, Amount);
            grossTotal += Amount;
            lblGrossTotal.Text = grossTotal.ToString();
        }

        private void btnGrandTotal_Click(object sender, EventArgs e)
        {
            Double total = 0;
            for(int i=0;i<dgvDetails.Rows.Count;i++)
            {
                total += Double.Parse(dgvDetails.Rows[i].Cells["A"].Value.ToString());
            }
            MessageBox.Show("The total Billing Amount : " + total.ToString());
            if(grossTotal<1000)
            {
                discount = 0.02 * grossTotal;
            }
            else if(grossTotal>=1000 && grossTotal<10000)
            {
                discount = 0.05 * grossTotal;
            }
            else if(grossTotal>=10000 && grossTotal<20000)
            {
                discount = 0.08 * grossTotal;
            }
            else if(grossTotal>=20000 && grossTotal<50000)
            {
                discount = 0.1 * grossTotal;
            }
            else if(grossTotal>=50000)
            {
                discount = 0.15 * grossTotal;
            }
            lblDiscount.Text = discount.ToString();
            Double netAmount = grossTotal - discount;
            lblNetAmount.Text = netAmount.ToString();
        }
    }
}
