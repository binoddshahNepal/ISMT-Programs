﻿using System;

namespace MenuProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\nEnter first number:\t");
            Double first = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter second number:\t");
            Double second = Double.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("---------MENU DRIVEN PROGRAM-----------------");
            Console.WriteLine("Press 1 to add");
            Console.WriteLine("Press 2 to subtract");
            Console.WriteLine("Press 3 to multiply");
            Console.WriteLine("Press 4 to divide");
            Console.WriteLine("Press any other number to exit");
            Console.Write("\nEnter your choice:\t");
            int choice = int.Parse(Console.ReadLine());
            if (choice == 1)
            {
                Double sum = first + second;
                Console.WriteLine("The sum of {0} and {1} is {2}", first, second, sum);
            }
            else if (choice == 2)
            {
                Double difference = first - second;
                Console.WriteLine("The difference of {0} and {1} is {2}", first, second, difference);
            }
            else if (choice == 3)
            {
                Double product = first * second;
                Console.WriteLine("The product of {0} and {1} is {2}", first, second, product);
            }
            else if (choice == 4)
            {
                Double quotient = first / second;
                Console.WriteLine("The quotient of {0} and {1} is {2}", first, second, quotient);
            }
            else
                return;
            Console.ReadLine();
        }
    }
}
