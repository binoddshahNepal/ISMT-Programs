﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArgumentedFunctionGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void clearGroupBox(Control ctrl)
        {
            foreach(Control c in ctrl.Controls)
            {
                if (c is TextBox)
                    c.Text = "";
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            clearGroupBox(groupBox1);
        }

        private void btnSecond_Click(object sender, EventArgs e)
        {
            clearGroupBox(groupBox2);
        }

        private void btnClearPanel_Click(object sender, EventArgs e)
        {
            clearGroupBox(panel1);
        }
    }
    
}
