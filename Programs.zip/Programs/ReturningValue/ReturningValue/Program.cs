﻿using System;

namespace ReturningValue
{
    class Program
    {
        public static Double  addition()
        {
            Double x = 100, y = 200;
            return x + y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("The sum of the numbers is : {0} ",addition());
            Console.ReadLine();
        }
    }
}
