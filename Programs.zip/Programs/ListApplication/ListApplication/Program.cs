﻿using System;
using System.Collections.Generic;
namespace ListApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program using List to store the names of any four subjects
            //inside a list and display them.
            List<String> subjectNames = new List<String>() {"Programming",
                "Network",
                "Database Design and Development",
                "Professional Practice" };
            Console.WriteLine("Details of the subjects");
            Console.WriteLine("..................................");
            foreach(String s in subjectNames)//You don't need any idea of size
            {
                Console.WriteLine(s);
            }
            Console.ReadLine();
            Console.WriteLine("Retrieving Value using For Loop");
            for (int i = 0; i <subjectNames.Count; i++)//You need to have the idea of size.
            {
                Console.WriteLine(subjectNames[i]);
            }
            Console.ReadLine();
        }
    }
}
