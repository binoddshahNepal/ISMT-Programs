﻿using System;

namespace ConditionalStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            String electricity = "";
            String internet = "";
            String studentsPresence = "";
            Console.Write("\nIs there electricity:\tYes-No\t");
            electricity = Console.ReadLine();
            if (electricity == "Yes")
            {
                Console.Write("\nIs there a internet available???\tYes-No\t");
                internet = Console.ReadLine();
                if (internet == "Yes")
                {
                    Console.Write("Are the students Present???\tYes-No\t");
                    studentsPresence = Console.ReadLine();
                    if (studentsPresence == "Yes")
                    {
                        Console.WriteLine("Hurray!!! We will be having a class today");
                    }
                    else { Console.WriteLine("No Class for today"); }
                }
                else { Console.WriteLine("No Class for today"); }
            }
            else {
                Console.WriteLine("Oh No! There won't be a class today");
            }
            Console.ReadLine();
           
        }
    }
}
