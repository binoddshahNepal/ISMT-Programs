﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillingApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int serial = 0;
        Double totalAmount = 0;
        private void btnAddToList_Click(object sender, EventArgs e)
        {
            serial++;
            String pName = txtProductName.Text;
            Double rate = Double.Parse(txtRate.Text);
            Double quantity = Double.Parse(txtQuantity.Text);
            Double amount = rate * quantity;
            totalAmount += amount;
            dgvDetails.Rows.Add(serial, pName, rate, quantity, amount);
            lblItemsCount.Text = serial.ToString();
            lblBillingAmount.Text = totalAmount.ToString();

        }
    }
}
