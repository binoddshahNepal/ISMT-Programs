﻿using System;

namespace FunctionReturning
{
    class Program
    {
        public static String displayName()    //Function Definition
        {
            String Name = "Yugal Shrestha";
            return Name;
        }
        public static Double sum()
        {
            Console.Write("\nEnter first value:\t");
            Double x = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter second value:\t");
            Double y = Double.Parse(Console.ReadLine());
            return x + y;

        }
        static void Main(string[] args)
        {
           // Console.WriteLine(displayName());
           
            Console.WriteLine("The sum of the numbers : {0}",sum());
            Console.ReadLine();
            String n = displayName();
            Double s = sum();
            Console.WriteLine("The sum of the numbers is : {0}", s);
            Console.WriteLine("The Name of the candidate : {0}", n);
            Console.ReadLine();
        }
    }
}
