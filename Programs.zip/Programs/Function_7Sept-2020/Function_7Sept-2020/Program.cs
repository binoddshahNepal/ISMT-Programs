﻿using System;

namespace Function_7Sept_2020
{
    class Program
    {
        static Double length, breadth, height;
        public static void getValues()
        {
            Console.Write("\nEnter the aread of floor:\t");
            length = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter the breadth of the room:\t");
            breadth = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter the height of the room:\t");
            height = Double.Parse(Console.ReadLine());
        }
        public static void areaofFloor()//Function Definition
        {
            getValues();
            Double af = length * breadth;
            Console.WriteLine("The area of the floor is : {0}", af);
        }
        public static void areaofFourWalls()//Function Definition
        {
            getValues();
            Double afw = 2 * height * (length + breadth);
            Console.WriteLine("The area of four walls is : {0}", afw);
        }
        public static void volume()//Function Definition
        {
            getValues();
            Double volume = length * breadth * height;
            Console.WriteLine("The volume of the room is : {0}", volume);
        }
        static void Main(string[] args)
        {
            areaofFloor();//Function Call
            areaofFourWalls();//Function Call
            volume();//Function
            Console.ReadLine();
        }
    }
}
