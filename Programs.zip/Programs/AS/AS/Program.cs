﻿using System;

namespace AS
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, d, n;
            Console.Write("\nEnter the first term:\t");
            a = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the common difference:\t");
            d = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the number of terms:\t");
            n = int.Parse(Console.ReadLine());
            Console.Clear();
            int sn = 0;
            Console.WriteLine("The terms of the arithmetic series are : \t");
            for(int i=1;i<=n;i++)
            {
                int tn = a + (i - 1) * d;
                Console.Write("{0}\t", tn);
                sn += tn;
            }
            int sum = (n / 2) * (2 * a + (n - 1) * d);
            Console.WriteLine("\nThe sum of series from for loop :    {0}", sn);
            Console.WriteLine("\nThe sum of series using formula :    {0}", sum);
            Console.ReadLine();
        }
    }
}
