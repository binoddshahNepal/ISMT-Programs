﻿using System;

namespace ArrayExample_2
{
    class Program
    {
        static void Main(string[] args)
        {
            String studentName, address, contact;
            String[] subjects = new string[100];
            Double[] fullmark = new double[100];
            Double[] passmark = new double[100];
            Double[] obtainedmark = new double[100];
            Double totalFullMark = 0, totalObtainedMark = 0, percentage = 0;
            Console.Write("\nEnter student name:\t");
            studentName = Console.ReadLine();
            Console.Write("\nEnter student address:\t");
            address = Console.ReadLine();
            Console.Write("\nEnter Contact Number:\t");
            contact = Console.ReadLine();
            Console.Clear();
            Console.Write("\nEnter total number of subject studied:\t");
            int n = int.Parse(Console.ReadLine());
            Console.Clear();
            for(int i=0;i<n;i++)
            {
                Console.Write("\nEnter subject name:\t");
                subjects[i] = Console.ReadLine();
                Console.Write("\nEnter full mark:\t");
                fullmark[i] = Double.Parse(Console.ReadLine());
                Console.Write("\nEnter pass mark:\t");
                passmark[i] = Double.Parse(Console.ReadLine());
                Console.Write("\nEnter obtained mark:\t");
                obtainedmark[i] = Double.Parse(Console.ReadLine());
                totalFullMark += fullmark[i];
                totalObtainedMark += obtainedmark[i];
            }
            Console.Clear();
            Console.WriteLine("------STUDENT DETAILS-------");
            Console.WriteLine("Student Name:   {0}", studentName);
            Console.WriteLine("Address:        {0}", address);
            Console.WriteLine("Contact:        {0}", contact);
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("\n------MARKS DETAILS-------");
            for(int i=0;i<n;i++)
            {
                Console.WriteLine("{0}\t\t\t{1}\t{2}\t{3}", subjects[i], fullmark[i], passmark[i], obtainedmark[i]);
            }
            Console.WriteLine("-------------------------------------------------------------");
            percentage = totalObtainedMark / totalFullMark * 100;
            Console.WriteLine("\nPERCENTAGE SCORED :    {0}", percentage);
            Console.ReadLine();
        }
    }
}
