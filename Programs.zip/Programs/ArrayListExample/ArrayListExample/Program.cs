﻿using System;
using System.Collections;
namespace ArrayListExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList names = new ArrayList();
            names.Add("Ram");
            names.Add("Shyam");
            names.Add("Hari");
            names.Add("Gopal");
            names.Add("Suresh");
            names.Add("Manish");
            ArrayList id = new ArrayList() { 1,2,3,4,5,6};
            foreach(String s in names)
            {
                Console.WriteLine(s);
            }
            foreach(int i in id)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.WriteLine(".......................................");
            for(int i=0;i<names.Count;i++)
            {
                Console.WriteLine("{0}\t{1}", id[i], names[i]);
            }
            Console.ReadLine();
        }
    }
}
