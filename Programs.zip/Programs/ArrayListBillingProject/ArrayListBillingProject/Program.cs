﻿using System;
using System.Collections;
namespace ArrayListBillingProject
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            ArrayList pName = new ArrayList();
            ArrayList rate = new ArrayList();
            ArrayList quantity = new ArrayList();
            Double amount = 0, totalAmount = 0;
            Console.Write("\nEnter the total number of products purchased:\t");
            n = int.Parse(Console.ReadLine());
            Console.Clear();
            for(int i=0;i<n;i++)
            {
                Console.Write("\nEnter the product name:\t");
                pName.Add(Console.ReadLine());
                Console.Write("\nEnter the rate:\t");
                rate.Add(Double.Parse(Console.ReadLine()));
                Console.Write("\nEnter the quantity:\t");
                quantity.Add(Double.Parse(Console.ReadLine()));

            }
            Console.Clear();
            Console.WriteLine("\nDETAILS OF THE ITEMS PURCHASED");
            Console.WriteLine("....................................................");
            for(int i=0;i<n;i++)
            {
                Double r = Convert.ToDouble(rate[i]);
                Double q = Convert.ToDouble(quantity[i]);
                amount = r * q;
                totalAmount += amount;
                Console.WriteLine("{0}\t\t{1}\t{2}\t{3}", pName[i], r, q, amount);
            }
            Console.WriteLine("....................................................");
            Console.WriteLine("TOTAL BILLING AMOUNT:{0}", totalAmount);
            Console.ReadLine();
        }
    }
}
