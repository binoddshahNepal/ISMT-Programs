﻿using System;

namespace FunctionExample_01
{
    class Program
    {
        public static void DisplayName() //Function Definition
        {
            Console.WriteLine("Enter your name:\t");
            String name = Console.ReadLine();
            Console.WriteLine("Hello! {0}. Welcome to advanced programming class", name);
        }
        static void Main(string[] args)
        {
            DisplayName();//Function Call
            Console.ReadLine();
            DisplayName();
            DisplayName();
        }
    }
}
