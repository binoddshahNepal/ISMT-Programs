﻿using System;

namespace forLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int number, limit;
            Console.Write("\nEnter the number whose table is to be found:\t");
            number = int.Parse(Console.ReadLine());
            Console.Write("\nEnter the limit for the table:\t");
            limit = int.Parse(Console.ReadLine());
            Console.Clear();
            for(int i=1;i<=limit;i++)
            {
                Console.WriteLine("{0} x {1} = {2}", number, i, number * i);
            }
            Console.ReadLine();
        }
    }
}
