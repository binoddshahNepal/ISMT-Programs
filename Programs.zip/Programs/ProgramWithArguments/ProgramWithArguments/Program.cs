﻿using System;

namespace ProgramWithArguments
{
    class Program
    {
        public static void sum(int a, int b)
        {
            int s = (a + b);
            Console.WriteLine("The sum of {0} and {1}  is {2}", a, b, s);
        }
        static void Main(string[] args)
        {
            sum(100, 200);
            Console.ReadLine();
        }
    }
}
