﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Function_01_15Sept_2020
{
    class Program
    {
        public static Double n1, n2;
        public static void getValues()
        {
            Console.Write("\nEnter the first number:\t");
            n1 = Double.Parse(Console.ReadLine());
            Console.Write("\nEnter the second number:\t");
            n2 = Double.Parse(Console.ReadLine());
        }
        public static Double Arithmetic(Double first, Double second, int Mode)
        {
            Double result = 0;
            switch (Mode)
            {
                case 1:
                    result = first + second;
                    break;
                case 2:
                    result = first - second;
                    break;
                case 3:
                    result = first * second;
                    break;
                case 4:
                    result = first / second;
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
            return result;
        }
        public static void menu()
        {
            
            int x = 1;
            while (x == 1)
            {
                Console.WriteLine("---THIS IS A MENU DRIVEN PROGRAM---");
                Console.WriteLine("****************************************************");
                Console.WriteLine("PRESS 1 TO ADD");
                Console.WriteLine("PRESS 2 TO SUBTRACT");
                Console.WriteLine("PRESS 3 TO MULTIPLY");
                Console.WriteLine("PRESS 4 TO DIVIDE");
                Console.WriteLine("PRESS ANY OTHER KEY TO EXIT");
                Console.Write("\nENTER YOUR CHOICE:\t");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        getValues();
                        Double sum = Arithmetic(n1,n2, 1);
                        Console.WriteLine("The sum of {0} and {1} is {2}", n1,n2, sum);
                        break;
                    case 2:
                        getValues();
                        Double difference = Arithmetic(n1,n2, 2);
                        Console.WriteLine("The difference of {0} and {1} is {2}", n1,n2, difference);
                        break;
                    case 3:
                        getValues();
                        Double product = Arithmetic(n1,n2, 3);
                        Console.WriteLine("The product of {0} and {1} is {2}", n1,n2, product);
                        break;
                    case 4:
                        getValues();
                        Double division = Arithmetic(n1,n2, 4);
                        Console.WriteLine("The division of {0} and {1} is {2}", n1,n2, division);
                        break;
                    default:
                        x = 2;
                        break;
                }
            }
        }
        static void Main(string[] args)
        {
            menu();
            Console.ReadLine();
        }
    }
}
