﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions_7Oct_2020
{
    class Program
    {
         static void printName()
        {
            Console.Write("\nEnter your first Name:\t");
            String firstName = Console.ReadLine();
            Console.Write("\nEnter your last Name:\t ");
            String lastName = Console.ReadLine();
            String fullName = firstName + " " + lastName;
            Console.Clear();
            Console.WriteLine("Welcome: {0}", fullName);
           
        }
         static String printFullName()
         {
             Console.Write("\nEnter your first Name:\t");
             String firstName = Console.ReadLine();
             Console.Write("\nEnter your last Name:\t ");
             String lastName = Console.ReadLine();
             String fullName = firstName + " " + lastName;
             return fullName;
         }
        static void Main(string[] args)
        {
           
            Console.WriteLine("Welcome: {0}",printFullName());
            String fn = printFullName();
            Console.WriteLine("Full Name: {0}", fn);
            Console.ReadLine();
        }
    }
}
