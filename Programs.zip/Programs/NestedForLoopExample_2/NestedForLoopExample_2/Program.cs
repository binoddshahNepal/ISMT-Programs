﻿using System;

namespace NestedForLoopExample_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int m, n;
            Double fMark = 0, oMark = 0,percent=0;
            Console.Write("\nEnter the total number of student:\t");
            n = int.Parse(Console.ReadLine());
            for(int i =0;i<n;i++)
            {
                Console.Write("\nEnter the student name:\t");
                String studentName = Console.ReadLine();
                Console.Write("\nEnter the number of subjects studied:\t");
                m = int.Parse(Console.ReadLine());
                Console.Clear();
                for(int j=0;j<m;j++)
                {
                    Console.Write("\nEnter the subject name:\t");
                    string subjectName = Console.ReadLine();
                    Console.Write("\nEnter the full mark:\t");
                    Double fullMark = Double.Parse(Console.ReadLine());
                    Console.Write("\nEnter the pass mark:\t");
                    Double passMark = Double.Parse(Console.ReadLine());
                    Console.Write("\nEnter the obtained mark:\t");
                    Double obtainedMark = Double.Parse(Console.ReadLine());
                    fMark += fullMark;
                    oMark += obtainedMark;
                    percent = oMark / fMark * 100;
                }
                Console.Clear();
                Console.WriteLine("Percentage Scored by {0} is {1}", studentName, percent);
                Console.WriteLine("Total Marks :         {0}", fMark);
                Console.WriteLine("Total Obtained Marks: {0}", oMark);
                fMark = 0; oMark = 0;
            }
            Console.ReadLine();
        }
    }
}
