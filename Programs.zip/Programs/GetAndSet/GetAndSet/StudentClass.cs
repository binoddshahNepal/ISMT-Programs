﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetAndSet
{
    class StudentClass
    {
        String name, address, contact;
        public void setValue(String Name,String Address,String Contact)
        {
            name = Name;
            address = Address;
            contact = Contact;
        }
        public void printValue()
        {
            Console.WriteLine("Student Name:   {0}", name);
            Console.WriteLine("Address     :   {0}", address);
            Console.WriteLine("Contact     :   {0}", contact);
        }
    }
}
