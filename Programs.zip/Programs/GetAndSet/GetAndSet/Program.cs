﻿using System;

namespace GetAndSet
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeClass ec = new EmployeeClass();
            ec.Age = 34;
            ec.Salary = 90000;
            ec.Name = "Harish Pandit Acharya";
            ec.Designation = "Supervisor";
            Console.WriteLine("Employee Name:    {0}", ec.Name);
            Console.WriteLine("Designation  :    {0}", ec.Designation);
            Console.WriteLine("Age          :    {0}", ec.Age);
            Console.WriteLine("Salary       :    {0}", ec.Salary);
            Console.ReadLine();

            StudentClass sc = new StudentClass();
           
            Console.WriteLine("Student Details");
            sc.setValue("Harish Pandit", "Kathmandu", "98989898");
            sc.printValue();
            Console.ReadLine();

        }
    }
}
