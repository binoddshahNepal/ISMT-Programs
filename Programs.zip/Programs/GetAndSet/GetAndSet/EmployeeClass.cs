﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GetAndSet
{
    class EmployeeClass
    {
        int age;
        Double salary;
        String name, designation;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public Double Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        public String Name
        {
            get { return name; }
            set { name = value; }
        }
        public String Designation
        {
            get { return designation; }
            set { designation = value; }
        }
    }
}
