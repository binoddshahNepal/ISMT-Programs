﻿using System;

namespace NestedForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
         for(int i=0;i<4;i++)
            {
                for(int j=0;j<4;j++)
                {
                    Console.Write("{0}\t", j);
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
