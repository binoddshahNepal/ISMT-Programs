﻿using System;

namespace ArrayApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] names = new string[5];
            int n;
            Console.WriteLine("\nEnter the total number of names:\t");
            n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.Write("\nEnter the name:\t");
                names[i] = Console.ReadLine();
            }
            for(int i=0;i<n;i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.ReadLine();
        }
    }
}
