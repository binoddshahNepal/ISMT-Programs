﻿using System;

namespace argumentedFunction
{
    class Program
    {
        public static void mathematics(int x, int y, int mode)
        {
            switch (mode)
            {
                case 1:
                    int sum = (x + y);
                    Console.WriteLine("The sum of {0} and {1} is {2}", x, y, sum);
                    break;
                case 2:
                    int diff = (x - y);
                    Console.WriteLine("The difference of {0} and {1} is {2}",x,y, diff);
                    break;
                case 3:
                    int product = (x * y);
                    Console.WriteLine("the product of {0} and {1} is {2}",x,y, product);
                    break;
                case 4:
                    int div = x / y;
                    Console.WriteLine("The division of {0} and {1} is {2}",x,y, div);
                    break;
                default:
                    Console.WriteLine("Invalid option");
                    break;
            }
        }
        static void Main(string[] args)
        {
            mathematics(100, 200, 5);
            mathematics(300, 400, 1);//Addition operation.
            mathematics(300, 400, 2);//Substraction operation.
            mathematics(500, 20, 3);//Product operation
            mathematics(400, 20, 4); //Division operation
            Console.ReadLine();

        }
    }
}
