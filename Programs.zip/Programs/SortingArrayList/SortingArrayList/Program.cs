﻿using System;
using System.Collections;

namespace SortingArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList names = new ArrayList() { "Book","Apple","Copies","Zebra","Water","Water Melon"};
            foreach(var n in names)
            {
                Console.WriteLine(n);
            }
            names.Sort();
            Console.WriteLine("\n IN ALPHABETICAL ORDER");
            Console.WriteLine("................................\n");
            foreach (var n in names)
            {
                Console.WriteLine(n);
            }
            names.Reverse();
          
            Console.WriteLine("\n IN ALPHABETICAL REVERSE ORDER");
            Console.WriteLine("................................\n");
            foreach (var n in names)
            {
                Console.WriteLine(n);
            }
            Console.ReadLine();
        }
    }
}
