﻿using System;
using System.Collections;
namespace ArrayListExample2
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList pname = new ArrayList();
            int n;
            Console.Write("\nEnter the total number of products purchased:\t");
            n = int.Parse(Console.ReadLine());
           // Console.Clear();
            for(int i=0;i<n;i++)
            {
                Console.Write("\nEnter product name:\t");
                pname.Add(Console.ReadLine());
            }
           // Console.Clear();
            Console.WriteLine("LIST OF ITEMS PURCHASED");
            Console.WriteLine("....................................");
            for(int i=0;i<n;i++)
            {
                Console.WriteLine(pname[i]);
            }
            Console.ReadLine();
        }
    }
}
